采用GNU GENERAL PUBLIC LICENSE, Version 3作为开源协议

注意:通用数据测试集(GDTS)里的数据遵循GDSL协议，请阅读同目录下的"GDSL.txt"获得更多信息。
